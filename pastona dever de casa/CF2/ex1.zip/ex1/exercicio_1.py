'''
Exercício 1 — Grupos de Pesquisa e seus Membros

O arquivo "grupos.txt" contém a lista de grupos de pesquisa cadastrados por um programa de iniciação científica.
Cada grupo possui um nome e a quantidade de pesquisadores participantes. Em seguida, cada linha traz o nome de um membro.

Exemplo de conteúdo do arquivo:
-----------------------------
Grupo Biotec,3
Ana Souza
Carlos Lima
Juliana Reis
Grupo IA Médica,2
Luiz Fernando
Mariana Alves

Faça um programa que, para cada grupo, mostrar seu nome quantidade  e a lista de membros com indentação.

Saída esperada:
Grupo Biotec (3 membros):
 - Ana Souza
 - Carlos Lima
 - Juliana Reis
Grupo IA Médica (2 membros):
 - Luiz Fernando
 - Mariana Alves
'''